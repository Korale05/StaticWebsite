<%-- 
    Document   : register.jsp
    Created on : 26 Oct 2026, 3:41:49 pm
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>User Registration Form </title>
    </head>
    <body>
        <h2>User Registration </h2>
    <form action="${pageContext.request.contextPath}/register" method="post">
        <label>Username :</label>
        <input type="text" name="username" required>
        <br><br>
        
        <label>Password :</label>
        <input type="password" name="password" required>
        <br><br>
        
        
        <button type="submit">Register</button>
    </form>
    </body>
</html>
