<%-- 
    Document   : login
    Created on : 26 Oct 2026, 5:16:13 pm
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login Page</title>
    </head>
    <body>
        <h1>Login Form </h1>
        <form action="${pageContext.request.contextPath}/login" method="post">
            <label>Username : </label>
            <input type="text"name="username" required>
            
            <br><br>
            
            <label>Password :</label>+
            <input name="password" type="text" required>
            
            <br><br>
            
            <button type="submit">Login</button>
        </form>
    </body>
</html>
