/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException , IOException
    {
        req.setCharacterEncoding("UTF-8");
        
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        
        String sql = "INSERT INTO user(username,password) VALUES(?,?)";
        try( Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ){
            statement.setString(1, username);
            statement.setString(2,password);
            
            statement.executeUpdate();
            
            res.setContentType("text/html;charset=UTF-8");
            res.getWriter().println(
                    "<h2>Registration Successfully</h2>"
                            + "<a herf='register.jsp'> Register Anouther User</a>"
            );
            
        }catch(SQLException e){
            throw new ServletException("Could not register user.", e);
        }
    }
}
