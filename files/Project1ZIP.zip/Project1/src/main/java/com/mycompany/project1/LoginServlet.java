/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project1;


import jakarta.servlet.ServletException;
import java.sql.*;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;



@WebServlet("/login")
public class LoginServlet extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
        req.setCharacterEncoding("UTF-8");
        
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String sql = "SELECT * FROM user WHERE username=? AND password=?";
        try(
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
         ){
            
            statement.setString(1, username);
            statement.setString(2, password);
            
            ResultSet result = statement.executeQuery();
            
            if(result.next()){
                res.setContentType("text/html;charset=UTF-8");
                res.getWriter().println(
                        "<h1> Login Successfully !</h1>"
                        + "<h2> Username : " + username+ "</h2>"
                );
            }else{
                res.setContentType("text/html;charset=UTF-8");
                res.getWriter().println(
                  "<h1> Unsuccessfull Login </h1>"      
                );
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
