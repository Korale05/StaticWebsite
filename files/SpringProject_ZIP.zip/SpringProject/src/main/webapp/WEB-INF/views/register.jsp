<%-- 
    Document   : register
    Created on : 26 Oct 2026, 7:28:02 pm
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register</title>
    </head>
    <body>
        <h1>Register a form </h1>
        <form action="${pageContext.request.contextPath}/register" method="post">
            
            <label>Username</label>
            <input name="username" type="text"required>
            <br>
            <br>
            <label>Password</label>
            <input name="password" type="password">
            
            <button type="submit">Register</button>
            
            
        </form>
    </body>
</html>
