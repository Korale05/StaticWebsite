<%-- 
    Document   : login
    Created on : 27 Oct 2026, 10:49:29 am
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>login a form </h1>
        <form action="${pageContext.request.contextPath}/login" method="post">
            
            <label>Username</label>
            <input name="username" type="text"required>
            <br>
            <br>
            <label>Password</label>
            <input name="password" type="password">
            
            <button type="submit">Register</button>
            
            
        </form>
    </body>
</html>
