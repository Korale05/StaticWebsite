<%-- 
    Document   : success
    Created on : 27 Oct 2026, 10:19:37 am
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Success</title>
    </head>
    <body>
        <h2>User Registered Successfully!</h2>
    </body>
</html>
