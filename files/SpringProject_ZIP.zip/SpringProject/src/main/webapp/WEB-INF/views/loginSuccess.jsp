<%-- 
    Document   : loginSuccess
    Created on : 27 Oct 2026, 10:44:50 am
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
    </head>
    <body>
        <h1>Login Success</h1>
    </body>
</html>
