<%-- 
    Document   : error
    Created on : 27 Oct 2026, 10:20:08 am
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>error</title>
    </head>
    <body>
        <h2>Registration Failed!</h2>
    </body>
</html>
