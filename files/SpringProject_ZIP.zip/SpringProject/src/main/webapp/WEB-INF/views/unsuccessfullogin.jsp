<%-- 
    Document   : unsuccessfullogin
    Created on : 27 Oct 2026, 10:46:52 am
    Author     : onkar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Unsuccessful Login </h1>
    </body>
</html>
