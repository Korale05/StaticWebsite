/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springproject;

import java.sql.*;
import org.springframework.web.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.service.annotation.PostExchange;

@Controller
public class Login {
    
    @GetMapping("/login")
    public String showfrom(){
        return "login";
    }
    
    @PostMapping("/login")
    public String login(
       @RequestParam("username") String username,
       @RequestParam("password") String password
    ){
        String sql = "SELECT * FROM user WHERE username=? AND password=?";
        
        try( Connection connection = DBConnection.getConnection();
             PreparedStatement stm = connection.prepareStatement(sql);
        ){
            stm.setString(1,username);
            stm.setString(2,password);
            ResultSet rs = stm.executeQuery();
            if(rs.next()){
                return "loginSuccess";
            }else{
                return "unsuccessfullogin";
            }
        }catch(Exception e){
            e.printStackTrace();
            return "error";
        }
    }
    
}
