/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springproject;

import java.sql.*;
import java.sql.PreparedStatement;

import org.springframework.stereotype.*;
import org.springframework.web.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class RegisterController {
    
    @GetMapping("/register")
    public String showform(){
        return "register";
    }
    
    @PostMapping("/register")
    public String register(
    @RequestParam("username") String name,
    @RequestParam("password") String password
    ){
        try{
            Connection connection = DBConnection.getConnection();
            String sql = "INSERT INTO user(username,password)VALUES(?,?)";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, name);
            stm.setString(2,password);
            stm.executeUpdate();
            stm.close();
            return "success";
        }catch(Exception e){
            e.printStackTrace();
            return "error";
        }
    }
}
